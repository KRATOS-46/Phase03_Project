package org.sportyshoes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportsShoeSpringProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
