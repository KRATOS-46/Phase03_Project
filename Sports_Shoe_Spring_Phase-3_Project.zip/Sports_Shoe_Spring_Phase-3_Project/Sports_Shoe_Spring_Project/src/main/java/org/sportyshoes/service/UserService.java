package org.sportyshoes.service;

import java.util.List;

import org.sportyshoes.entity.User;
import org.sportyshoes.model.UserModel;
import org.sportyshoes.repository.UserRepository;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	public UserRepository userRepo;

	public UserService(UserRepository userRepo) {
		super();
		this.userRepo = userRepo;
	}

	public void userRegister(UserModel usermodel) {
		User user = new User();
		user.setName(usermodel.getName());
		user.setGender(usermodel.getGender());
		user.setEmail(usermodel.getEmail());
		user.setPhonenumber(usermodel.getPhonenumber());
		userRepo.save(user);
	}

	public List<User> getAllUser() {
		Iterable<User> it = this.userRepo.findAll();
		List<User> allUsers = Streamable.of(it).toList();
		return allUsers;
	}

	public void deleteUser(int id) {
		userRepo.deleteById(id);
	}

	public List<User> getUserbyName(String name) {
		Iterable<User> it = userRepo.findByName(name);
		List<User> users = Streamable.of(it).toList();
		return users;
	}

}
