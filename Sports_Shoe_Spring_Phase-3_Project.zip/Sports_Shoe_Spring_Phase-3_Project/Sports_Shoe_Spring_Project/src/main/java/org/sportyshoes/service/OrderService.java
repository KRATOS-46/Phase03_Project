package org.sportyshoes.service;

import java.time.LocalDate;
import java.util.List;

import org.sportyshoes.entity.Orders;
import org.sportyshoes.entity.Product;
import org.sportyshoes.model.OrdersModel;
import org.sportyshoes.repository.OrdersRepository;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;
@Service
public class OrderService {
	public OrdersRepository orderRepo;

	public OrderService(OrdersRepository orderRepo) {
		super();
		this.orderRepo = orderRepo;
	}
	public void addOrder(OrdersModel om,Product product) {
		Orders order = new Orders();
		order.setUsername(om.getUsername());
		order.setAddress(om.getAddress());
		order.setLandmark(om.getLandmark());
		order.setState(om.getState());
		order.setPincode(om.getPincode());
		order.setCategory(om.getCategory());
		order.setProduct(product);
		orderRepo.save(order);
	}
	public List<Orders> getOrder(String category,LocalDate date) {
		Iterable<Orders> it = orderRepo.findByCategoryAndDate(category, date);
		List<Orders> order = Streamable.of(it).toList();
		return order;
		
	}
	public void deleteOrder (int id) {
		orderRepo.deleteById(id);
	}

}
