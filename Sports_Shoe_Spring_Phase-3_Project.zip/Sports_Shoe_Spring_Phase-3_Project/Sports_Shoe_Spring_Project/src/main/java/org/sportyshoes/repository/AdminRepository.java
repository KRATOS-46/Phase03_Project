package org.sportyshoes.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.sportyshoes.entity.Admin;

public interface AdminRepository extends JpaRepositoryImplementation<Admin, Integer>{
	public Admin findByUsernameAndPassword(String username, String password);

}
