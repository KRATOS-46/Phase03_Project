package org.sportyshoes.service;

import org.sportyshoes.entity.Admin;

import org.sportyshoes.model.AdminModel;

import org.sportyshoes.repository.AdminRepository;
import org.springframework.stereotype.Service;

@Service
public class AdminService {
	public AdminRepository adminrepo;

	public AdminService(AdminRepository adminrepo) {
		super();
		this.adminrepo = adminrepo;
	}

	public Admin login(AdminModel adminmodel) {
		Admin admin = adminrepo.findByUsernameAndPassword(adminmodel.getName(), adminmodel.getPassword());
		return admin;
	}

}
