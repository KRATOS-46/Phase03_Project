package org.sportyshoes.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;

import java.util.List;

import org.sportyshoes.entity.User;

public interface UserRepository extends JpaRepositoryImplementation<User, Integer>{
	public List<User> findByName(String name);
}
