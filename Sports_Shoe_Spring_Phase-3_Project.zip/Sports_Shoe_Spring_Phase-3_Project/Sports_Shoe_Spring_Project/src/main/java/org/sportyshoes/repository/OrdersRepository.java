package org.sportyshoes.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;

import java.time.LocalDate;

import org.sportyshoes.entity.Orders;

public interface OrdersRepository extends JpaRepositoryImplementation<Orders, Integer> {
	public Iterable<Orders> findByCategoryAndDate(String category, LocalDate date);
}
