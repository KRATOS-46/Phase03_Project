package org.sportyshoes.service;

import java.util.List;
import java.util.Optional;

import org.sportyshoes.entity.Product;
import org.sportyshoes.model.ProductModel;
import org.sportyshoes.repository.ProductRepository;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;
@Service
public class ProductService {
	public ProductRepository productrepo;

	
	public ProductService(ProductRepository productrepo) {
		super();
		this.productrepo = productrepo;
	}


	public void addProduct(ProductModel prdModel) {
		Product product = new Product();
		product.setPid(prdModel.getPid());
		product.setName(prdModel.getName());
		product.setBrand(prdModel.getBrand());
		product.setGender(prdModel.getGender());
		product.setPrice(prdModel.getPrice());
		product.setSize(prdModel.getSize());
		product.setType(prdModel.getType());
		productrepo.save(product);
	}
	public List<Product> getAllProduct() {
		Iterable<Product> it = productrepo.findAll();
		List<Product> products = Streamable.of(it).toList();
		return products;
	}
	public void deleteProduct(int pid) {
		productrepo.deleteById(pid);
	}
	public Product updateProduct(int pid) {
		Product newproduct = productrepo.findById(pid).get();
		return newproduct;
	}
	public List<Product> sortProduct(String brand,int size,String Type) {
			Iterable<Product> it = productrepo.findByBrandAndSizeAndType(brand, size, Type);
			List<Product> newproduct=Streamable.of(it).toList();
			return newproduct;	
	}
	public Product findProduct(int pid) {
		Optional<Product> optionalProduct = productrepo.findById(pid);
		Product newproduct=optionalProduct.orElse(null);
		return newproduct;	
}
	

}
 