package org.sportyshoes.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;



import org.sportyshoes.entity.Product;


public interface ProductRepository extends JpaRepositoryImplementation<Product, Integer>{
	public Iterable<Product> findByBrandAndSizeAndType(String brand, int size, String type);
}
