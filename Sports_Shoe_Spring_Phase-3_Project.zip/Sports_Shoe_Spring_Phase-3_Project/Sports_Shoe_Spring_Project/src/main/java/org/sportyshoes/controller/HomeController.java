package org.sportyshoes.controller;

import java.time.LocalDate;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.sportyshoes.entity.Admin;
import org.sportyshoes.entity.Orders;
import org.sportyshoes.entity.Product;
import org.sportyshoes.entity.User;
import org.sportyshoes.model.AdminModel;
import org.sportyshoes.model.OrdersModel;
import org.sportyshoes.model.ProductModel;
import org.sportyshoes.model.UserModel;
import org.sportyshoes.service.AdminService;
import org.sportyshoes.service.OrderService;
import org.sportyshoes.service.ProductService;
import org.sportyshoes.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

	public HomeController() {
		super();
	}

	@Autowired
	public AdminService adminservice;
	@Autowired
	public ProductService productservice;
	@Autowired
	public UserService userservice;
	@Autowired
	public OrderService orderservice;

	@GetMapping("/home")
	public String showHome() {
		return "home";
	}

	@GetMapping("/showAdminLogin")
	public String adminLogin() {
		return "adminLoginPage";
	}

	@GetMapping("/showRegister")
	public String userRegister() {
		return "addUser";
	}

	@GetMapping("/showProducts")
	public String sortProducts() {
		return "showProducts";
	}

	@GetMapping("/buyProduct")
	public String buyProduct(@RequestParam("brand") String brand, @RequestParam("size") String size,
			@RequestParam("type") String type, Model model) {
		List<Product> products = productservice.sortProduct(brand, Integer.parseInt(size), type);
		model.addAttribute("products", products);
		if (products.isEmpty()) {
			model.addAttribute("message", "No products found!");
			return "buyNow";
		} else {
			return "buyNow";
		}
	}

	@GetMapping("/orderProduct")
	public String orderProduct(@RequestParam("pid") String pid, Model model) {
		Product product = productservice.updateProduct(Integer.parseInt(pid));
		model.addAttribute("product", product);
		return "orderNow";
	}

	@PostMapping("/placeOrder")
	public String orderCreation(@ModelAttribute("om") OrdersModel om, BindingResult result, Model model,
			@RequestParam("pid") String pid) {
		Product product = productservice.updateProduct(Integer.parseInt(pid));
		orderservice.addOrder(om, product);
		model.addAttribute("message", "Order Placed Successfully");
		return "orderPlaced";

	}

	@PostMapping("/addUser")
	public String addUser(@ModelAttribute("userModel") UserModel usermodel, BindingResult result, Model model) {
		if (result.hasErrors()) {
			System.out.println(result);
			return "addUser";
		}

		else {
			userservice.userRegister(usermodel);
			model.addAttribute("message", "User Added Successfully");
			return "addUser";
		}
	}

	@PostMapping("/adminLogin")
	public String adminLogin(@RequestParam("username") String username, @RequestParam("password") String password,
			@Valid Admin admin, BindingResult result) {
		AdminModel adminModel = new AdminModel();
		adminModel.setName(username);
		adminModel.setPassword(password);
		Admin adminE = adminservice.login(adminModel);
		if (adminE != null) {
			System.out.println("Invalid Credentials");
			System.out.println(result);
			return "home";
		} else

			System.out.println("Login successfully");
		return "adminDashboard";
	}

	@GetMapping("/getAddProduct")
	public String getAddProduct(Model model) {
		return "addProduct";
	}

	@PostMapping("/addProduct")
	public String addProduct(@ModelAttribute("pm") ProductModel pm, BindingResult result, Model model) {

		if (result.hasErrors()) {
			System.out.println(result);
			return "addProduct";
		} else {
			productservice.addProduct(pm);
			model.addAttribute("message", "Product added successfully");
			return "addProduct";
		}
	}

	@GetMapping("/getAllProduct")
	public String getProducts(Model model) {
		List<Product> products = this.productservice.getAllProduct();
		model.addAttribute("products", products);
		if (products.isEmpty()) {
			model.addAttribute("message", "No Product Available!");
			return "getAllProduct";
		} else {
			return "getAllProduct";
		}
	}

	@GetMapping("/deleteProduct")
	public String deleteproduct(@RequestParam("pid") String pid) {
		productservice.deleteProduct(Integer.parseInt(pid));
		return "redirect:/getAllProduct";
	}

	@GetMapping("/updateProduct")
	public String updateProduct(@RequestParam("pid") String pid, Model model) {
		Product newproduct = productservice.updateProduct(Integer.parseInt(pid));
		model.addAttribute("product", newproduct);
		return "addProduct";
	}

	@GetMapping("/getUsers")
	public String getUser(Model model) {
		List<User> users = this.userservice.getAllUser();
		model.addAttribute("users", users);
		if (users.isEmpty()) {
			model.addAttribute("message", "No Users Registered!");
			return "getAllUser";
		} else
			return "getAllUser";
	}

	@GetMapping("/deleteuser")
	public String deleteUser(@RequestParam("id") String id) {
		userservice.deleteUser(Integer.parseInt(id));
		return "redirect:/getUsers";
	}

	@GetMapping("/showUsers")
	public String showUser(@RequestParam("name") String name, Model model) {
		List<User> users = this.userservice.getUserbyName(name);
		model.addAttribute("users", users);
		model.addAttribute("value", name);
		if (users.isEmpty()) {
			model.addAttribute("message", "No such user found!");
			return "getAllUser";
		} else {
			return "getAllUser";
		}

	}

	@GetMapping("/getAllOrders")
	public String getOrder() {
		return "getAllOrders";
	}

	@GetMapping("/showOrder")
	public String showOrders(@RequestParam("category") String category, @RequestParam("date") String date,
			Model model) {
		List<Orders> orders = orderservice.getOrder(category, LocalDate.parse(date));
		model.addAttribute("orders", orders);
		if (orders.isEmpty()) {
			model.addAttribute("message", "No such order found!");
			return "showOrders";
		} else {
			return "showOrders";
		}
	}
	@GetMapping("/productDetail")
		public String deleteOrder(@RequestParam("pid") String pid, Model model) {
		Product newproduct = productservice.findProduct(Integer.parseInt(pid));
		model.addAttribute("product", newproduct);
		return "getAllProductByID";
	}
	@GetMapping("/deleteOrder")
	public String deleteOrder(@RequestParam("id") String id) {
		orderservice.deleteOrder(Integer.parseInt(id));
		return "getAllOrders";
	}

	@GetMapping("/logout")
	public String logout(Model model, HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		if (session != null) {
			session.invalidate();
		}
		System.out.println("Logout successfully");
		model.addAttribute("message", "Logged out successfully!");
		return "Logout";
	}

}
