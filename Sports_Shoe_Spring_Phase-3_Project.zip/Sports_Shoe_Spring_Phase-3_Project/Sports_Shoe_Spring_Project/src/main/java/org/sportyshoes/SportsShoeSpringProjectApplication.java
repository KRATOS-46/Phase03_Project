package org.sportyshoes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportsShoeSpringProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SportsShoeSpringProjectApplication.class, args);
	}

}
